#include <iostream>
#include "NoteStore.h"
using  namespace std;

int main(void) {
    
    NoteStoreClient client;
    return 0;
}