#define	PATH_SQUARE_DOOR	"/tmp/squareproc_door"

typedef struct {		/* input to squareproc() */
  long	arg1;
} squareproc_in_t;

typedef struct {		/* output from squareproc() */
  long	res1;
} squareproc_out_t;
